export { GET } from "./route"
